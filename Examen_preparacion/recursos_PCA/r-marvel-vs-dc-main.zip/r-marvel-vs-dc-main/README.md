# r-marvel-vs-dc
DC Comics vs Marvel Comics - Exploratory Data Analysis and Data Visualization with R. Who has the smartest, strongest, fastest, or most powerful hero or villain? How to answer this and more questions with R. Medium article: https://cosmoduende.medium.com/dc-comics-vs-marvel-comics-exploratory-data-analysis-and-data-visualization-with-r-da557892c2f6

### *Versión en español*
Marvel Comics vs DC Comics — Análisis exploratorio y Visualización de Datos con R. ¿Quién tiene al héroe o villano más inteligente, hábil, rápido o poderoso? Cómo responder a esta y más preguntas con R. Artículo en Medium: https://cosmoduende.medium.com/dc-comics-vs-marvel-comics-an%C3%A1lisis-exploratorio-y-visualizaci%C3%B3n-de-datos-con-r-b0cf565e44e2

#### *Project preview*
https://www.youtube.com/watch?v=nqttpR7WO_c

